# Dataset audit

Generated 2026-10-26T13:36:12+00:00 by `scripts/01_verify_data.py`. Fingerprints were recorded from archive.ics.uci.edu on 26 Oct 2026.

## wdbc (UCI 17): OK

- Zip SHA-256 match: True; member `wdbc.data` SHA-256 match: True
- Rows 569, features 30, positives 212, negatives 357
- Missing cells 0  (rows with missing: 0)
- Exact duplicate rows 0; feature-only duplicates 0; duplicate groups with conflicting labels 0
- Feature types: {'continuous': 30}; type checks failed: none; constant columns: none
- Discrepancies vs. design report: none

## dr_debrecen (UCI 329): OK

- Zip SHA-256 match: True; member `messidor_features.arff` SHA-256 match: True
- Rows 1151, features 19, positives 611, negatives 540
- Missing cells 0  (rows with missing: 0)
- Exact duplicate rows 5; feature-only duplicates 5; duplicate groups with conflicting labels 0
- Feature types: {'continuous': 10, 'count': 6, 'binary': 3}; type checks failed: none; constant columns: none
- Discrepancies vs. design report: none

## cleveland (UCI 45): OK

- Zip SHA-256 match: True; member `processed.cleveland.data` SHA-256 match: True
- Rows 303, features 13, positives 139, negatives 164
- Missing cells 6 {'ca': 4, 'thal': 2} (rows with missing: 6)
- Exact duplicate rows 0; feature-only duplicates 0; duplicate groups with conflicting labels 0
- Feature types: {'continuous': 5, 'nominal': 4, 'binary': 3, 'count': 1}; type checks failed: none; constant columns: none
- Discrepancies vs. design report: none

Overall: OK